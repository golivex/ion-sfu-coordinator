# Bug reporting

A good bug report has some very specific qualities, so please read over our short document on [reporting bugs][report_bugs] before submitting a bug report.

To ask a question, go ahead and ignore this.

[report_bugs]: https://github.com/coreos/etcd/blob/master/Documentation/reporting_bugs.md
