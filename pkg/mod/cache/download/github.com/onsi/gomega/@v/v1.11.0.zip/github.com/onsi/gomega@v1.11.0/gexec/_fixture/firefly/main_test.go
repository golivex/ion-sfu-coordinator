package main_test

import "testing"

func Test(t *testing.T) {
	t.Log("Hum, it seems okay.")
}
