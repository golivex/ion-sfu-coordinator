// Package dtls implements Datagram Transport Layer Security (DTLS) 1.2
package dtls
