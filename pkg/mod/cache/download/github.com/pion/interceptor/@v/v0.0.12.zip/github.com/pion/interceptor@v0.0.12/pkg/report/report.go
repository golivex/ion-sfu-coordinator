// Package report provides interceptors to implement sending sender and receiver reports.
package report
