// Package mdns implements mDNS (multicast DNS)
package mdns
