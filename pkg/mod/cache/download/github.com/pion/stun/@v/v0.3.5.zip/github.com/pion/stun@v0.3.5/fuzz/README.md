# Fuzzer corpus

fuzz directory contains corpus for fuzzer.
