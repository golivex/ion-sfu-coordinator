# Test data

testdata directory contains data that is used as input for tests.
Data was gathered from real world implementations of STUN in
Firefox and Chrome browsers.