// +build !packetioSizeHardlimit

package packetio

const sizeHardlimit = false
