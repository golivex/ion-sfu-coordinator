# Check out the new, idiomatic GCP library

https://github.com/googleapis/google-cloud-go

https://godoc.org/cloud.google.com/go

## Each package contains its own examples

https://godoc.org/cloud.google.com/go/bigquery#pkg-examples

https://godoc.org/cloud.google.com/go/pubsub#pkg-examples

https://godoc.org/cloud.google.com/go/storage#pkg-examples

If you are still looking for Google Cloud examples from this library check out [3639d6d](https://code.googlesource.com/google-api-go-client/+/3639d6d93f377f39a1de765fa4ef37b3c7ca8bd9/examples/)
